#! /usr/bin/env bash
if [[ $1 == "--test-info" ]]; then
    echo "Follow Arguments: Nominuses"
    exit
fi
echo "../nominus_followers -i Vladimir Georgy Angy --nono -o chaos mess --output --ausgabe question"
../nominus_followers -i Vladimir Georgy Angy --nono -o chaos mess --output --ausgabe question

echo "../nominus_followers -i Vladimir Georgy -oAngy"
../nominus_followers -i Vladimir Georgy -oAngy

